package com.WalletPay.demo.dao;

import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.WalletPay.demo.WalletPayApplication;
import com.WalletPay.demo.Logger.GlobalLogger;
import com.WalletPay.demo.controller.WalletController;
import com.WalletPay.demo.entity.Transaction_Details;
import com.WalletPay.demo.entity.Wallet;
import com.WalletPay.demo.repo.TransactionRepository;
import com.WalletPay.demo.repo.WalletRepository;
@Repository
public class WalletPayDaoImpl implements WalletPayDao {
	
	private Logger logger=GlobalLogger.getLogger(WalletPayDaoImpl.class);
	
	@Autowired
	private WalletRepository walletRepository;
	@Autowired
	private TransactionRepository transactionRepository;

	public Wallet addUser(Wallet newuser) {
		
		String method="addUser(Wallet newuser)";
		logger.info(method + "called.."); 
		
		System.out.println(newuser); //
		newuser.setWallet_Ammount(0);
		return walletRepository.save(newuser);
	}

	public Wallet getUser(String Mobile_Number) {

		String method="getUser(String Mobile_Number)";
		logger.info(method + "called.."); 
		
		Wallet w1 =  walletRepository.getOne(Mobile_Number);
		System.out.println(w1);
		return w1;
	}
	public Wallet updateUser(Wallet newuser) {
		
		String method="updateUser(Wallet newuser)";
		logger.info(method + "called..");
		
		return walletRepository.save(newuser);
	}
	
	public String transferFund(String send_upi_id, String rec_upi_id, int ammount, String caption) { 
		
		String method="transferFund(String send_upi_id,String rec_upi_id,int ammount, String caption)";
		logger.info(method + "called..");
		
     Wallet send = walletRepository.getOne(send_upi_id);
		
		System.out.println("this is sending onj :- "+send);
		Wallet rec = walletRepository.getOne(rec_upi_id);
		
		System.out.println("this is reciver :- "+ rec);
		
		if ( send.getWallet_Ammount() >= ammount) {
		
		String id = send_upi_id+"#"+Calendar.getInstance().getTime()+"#"+rec_upi_id;
		
		//---------------- debit process --------------
		Transaction_Details sendbal = new Transaction_Details(id,ammount, caption, Calendar.getInstance().getTime());
		send.setWallet_Ammount(send.getWallet_Ammount() - sendbal.getT_ammount());
		
		List<Transaction_Details> t = send.getTransaction();
		t.add(sendbal);
		send.setTransaction(t);
		
		transactionRepository.save(sendbal);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// ----------------credit process-------------------------
		String id1 = send_upi_id+"#"+Calendar.getInstance().getTime()+"#"+rec_upi_id;
		Transaction_Details recbal = new Transaction_Details(id1,ammount, caption, Calendar.getInstance().getTime());
		
		rec.setWallet_Ammount(rec.getWallet_Ammount() + recbal.getT_ammount());
		
		
		
		List<Transaction_Details> t2 = rec.getTransaction();
		t2.add(recbal);
		rec.setTransaction(t2);
		
		
		transactionRepository.save(recbal);
		//----------------------------------------------------
		
		//wallet update
		
		walletRepository.save(send);
		walletRepository.save(rec);
	
		return "fund transfer successful";
		}
		else
		{
			return "transaction failed  'Unsufficient balance'. ";
		}
		
	}

	public String addBalanceToWallet(String upi_id, int ammount) {
		
		String method="addBalanceToWallet(String upi_id,int ammount)";
		logger.info(method + "called..");
		
      Wallet w1 = walletRepository.getOne(upi_id);
		
		String id = upi_id+"#"+Calendar.getInstance().getTime()+"#balanceAdded";
		
		Transaction_Details addbal = new Transaction_Details(id,ammount, "wallet_balance_added", Calendar.getInstance().getTime());
		
		w1.setWallet_Ammount(w1.getWallet_Ammount() + addbal.getT_ammount());
		List<Transaction_Details> t = w1.getTransaction();
		t.add(addbal);
		w1.setTransaction(t);
		
		transactionRepository.save(addbal);
		walletRepository.save(w1);
		
		return "Balance added to Wallet successful...";
	}

	public List<Transaction_Details> getTransaction(String upi_id) {
		
		String method="getTransaction(String upi_id)";
		logger.info(method + "called.."); 
		
		Wallet w1 = walletRepository.getOne(upi_id);
		return w1.getTransaction();
	}

	public String addBalanceToBank(String upi_id, int ammount) {
		
		String method="addBalanceToBank(String upi_id,int ammount)";
		logger.info(method + "called.."); 	
		
       Wallet w1 = walletRepository.getOne(upi_id);
		
		if (w1.getWallet_Ammount()>=ammount)
		{

		String id = upi_id+"#"+Calendar.getInstance().getTime()+"#bankDeposited";

		Transaction_Details addbal = new Transaction_Details(id,ammount, "wallet_balance_Deposited", Calendar.getInstance().getTime());

		w1.setWallet_Ammount(w1.getWallet_Ammount() - addbal.getT_ammount());
		List<Transaction_Details> t = w1.getTransaction();
		t.add(addbal);
		w1.setTransaction(t);
		transactionRepository.save(addbal);
		walletRepository.save(w1);
		return "Balance added to Bank successful...";
		}   
		else
		{
			return "Unsufficient balance...";
		}
	}

	

}
