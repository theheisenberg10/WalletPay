package com.WalletPay.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.WalletPay.demo.entity.Transaction_Details;

public interface TransactionRepository extends JpaRepository<Transaction_Details, String> {

}
