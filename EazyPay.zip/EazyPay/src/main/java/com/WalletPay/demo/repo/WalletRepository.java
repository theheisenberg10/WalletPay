package com.WalletPay.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.WalletPay.demo.entity.Wallet;

public interface WalletRepository extends JpaRepository<Wallet, String> {

}
