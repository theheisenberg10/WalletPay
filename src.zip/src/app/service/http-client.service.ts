import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http'
import { Observable } from 'rxjs';

export class Wallet{
  constructor(
    public mobile_Number:String,
		public email_id:String,
    public adhar_Number:String,
    public name:String,
    public wallet_Ammount : string,
    public wallet_Pin:string,
    public transaction : Transacion_Details
  ){}
}

export class Transacion_Details{
constructor(
  public t_id : string,
  public t_ammount:string,
  public caption:string,
  public t_date :string,
 
){}

}



@Injectable({
  providedIn: 'root'
})
export class HttpClientService {

  constructor(
     private httpClient:HttpClient
  ) { }


  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':'application/json',
      
    })
    
  }

public doSignUp(wallet1):Observable<Wallet>{

  console.log(wallet1); //2nd

  return this.httpClient.post<Wallet>(`http://localhost:3333/createNewUser`,JSON.stringify(wallet1), this.httpOptions); //wallet1,{responseType:'text' as 'json'});  //
}

public addbal(user,amount):Observable<any>{


  return this.httpClient.put<any>("http://localhost:3333/addBalanceToWallet/"+user+"/"+amount,this.httpOptions, {responseType:'text' as 'json'});
}

public depositbal(user,amount):Observable<any>{

  return this.httpClient.put<any>("http://localhost:3333/BankDeposit/"+user+"/"+amount,this.httpOptions,{responseType:'text' as 'json'});

}

public trasfer(user, receiver, amount, caption):Observable<any>{

  return this.httpClient.put<any>("http://localhost:3333/fundTransfer/"+user+"/"+receiver+"/"+amount+"/"+caption,this.httpOptions,{responseType:'text' as 'json'});
  
}

public getTransactionList(user):Observable<any>{

  return this.httpClient.get("http://localhost:3333/getTransaction/"+user);
}
 

}